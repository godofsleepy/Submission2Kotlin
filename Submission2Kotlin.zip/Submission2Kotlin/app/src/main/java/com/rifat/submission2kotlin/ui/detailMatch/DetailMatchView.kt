package com.rifat.submission2kotlin.ui.detailMatch

import com.rifat.submission2kotlin.model.Match

interface DetailMatchView {
    fun ShowMatch(data: Match)
}